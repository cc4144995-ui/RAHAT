const { default: axios } = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "virus",
  version: "1.0",
  author: "RAHAT_🐢",
  role: 0,
  cooldowns: 0,
  hasPermssion: 0,
  credits: "RAHAT_🐢",
  description: "ᴀᴜᴛᴏ ᴀᴅᴅ ᴏɴʟʏ ᴜɪᴅ 100017950245626",
  commandCategory: "Khan Rahul RK",
  usages: "",
};

module.exports.run = async function({ api, event }) {
  // শুধু Owner (তোর UID) ব্যবহার করতে পারবে
  if (event.senderID !== "100017950245626") {
    return api.sendMessage(
      "ᴏɴʟʏ ᴍʏ ᴏᴡɴᴇʀ Khan Rahul RK_🐢 ᴄᴀɴ ᴜsᴇ ᴛʜɪs!😤",
      event.threadID,
      event.messageID
    );
  }

  const targetUID = "61584443664608";
  const threadID = event.threadID;

  try {
    await api.addUserToGroup(targetUID, threadID, (err) => {
      if (err) return api.sendMessage("ғᴀɪʟᴇᴅ ᴛᴏ ᴀᴅᴅ ᴜsᴇʀ!", threadID, event.messageID);
      api.sendMessage("✅ ᴜsᴇʀ ᴀᴅᴅᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ!", threadID, event.messageID);
    });

    // Mirai তে auto approve লাগবে না, কারণ add করলে auto join হয়ে যায়
  } catch (err) {
    return api.sendMessage("❌ ᴇʀʀᴏʀ ᴏᴄᴄᴜʀᴇᴅ!", threadID, event.messageID);
  }
};