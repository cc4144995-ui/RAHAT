const axios = require("axios");
const fs = require("fs");
const path = require("path");
const FormData = require("form-data");

// === API utils ===
async function getStreamFromURL(url) {
  const res = await axios.get(url, { responseType: "stream" });
  return res.data;
}

function generateRandomId(len = 16) {
  const chars = "abcdef0123456789";
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

async function getBalance() {
  const pack = generateRandomId();
  await axios.post("https://api.getglam.app/rewards/claim/hdnu30r7auc4kve", null, {
    headers: {
      "User-Agent": "Glam/1.58.4 Android/32 (Samsung SM-A156E)",
      "glam-user-id": pack,
      "user_id": pack,
      "glam-local-date": new Date().toISOString(),
    },
  });
  return pack;
}

async function uploadFile(pack, stream, prompt, duration = 5) {
  const form = new FormData();
  form.append("package_id", pack);
  form.append("media_file", stream);
  form.append("media_type", "image");
  form.append("template_id", "community_img2vid");
  form.append("template_category", "20_coins_dur");
  form.append(
    "frames",
    JSON.stringify([
      {
        prompt,
        custom_prompt: prompt,
        start: 0,
        end: 0,
        timings_units: "frames",
        media_type: "image",
        style_id: "chained_falai_img2video",
        rate_modifiers: { duration: duration.toString() + "s" },
      },
    ])
  );

  const res = await axios.post("https://android.getglam.app/v2/magic_video", form, {
    headers: { ...form.getHeaders(), "User-Agent": "Glam/1.58.4 Android/32 (Samsung SM-A156E)" },
  });

  return res.data.event_id;
}

async function getStatus(taskID, pack) {
  while (true) {
    const res = await axios.get("https://android.getglam.app/v2/magic_video", {
      params: { package_id: pack, event_id: taskID },
      headers: { "User-Agent": "Glam/1.58.4 Android/32 (Samsung SM-A156E)" },
    });
    if (res.data.status === "READY") return [res.data];
    await new Promise((r) => setTimeout(r, 2000));
  }
}

async function imgToVideo(prompt, filePath, duration = 5) {
  const pack = await getBalance();
  const task = await uploadFile(pack, fs.createReadStream(filePath), prompt, duration);
  return await getStatus(task, pack);
}

// === Command config ===
module.exports.config = {
  name: "animate",
  version: "1.2.0",
  credits: "nazrul🇧🇩RAHAT🇧🇩",
  description: "AI দ্বারা ছবিকে ছোট ভিডিওতে পরিণত করে।",
  usages: "reply photo with: animate <prompt> | <duration>s",
  cooldowns: 10,
  commandCategory: "fun",
  hasPermission: 0,
};

// === Command run ===
module.exports.run = async function ({ api, event, args }) {
  const fullText = args.join(" ");
  if (!fullText)
    return api.sendMessage("❌ অনুগ্রহ করে একটি prompt দিন!\nউদাহরণ: animate anime girl dancing | 8s", event.threadID, event.messageID);

  let prompt = fullText;
  let duration = 5;
  const durationMatch = fullText.match(/\|\s*(\d+)s?/i);
  if (durationMatch) {
    duration = parseInt(durationMatch[1]);
    prompt = fullText.replace(/\|\s*\d+s?/i, "").trim();
  }

  if (!event.messageReply || !event.messageReply.attachments || event.messageReply.attachments.length === 0) {
    return api.sendMessage("❌ অনুগ্রহ করে কোনো ছবিতে রিপ্লাই দিয়ে কমান্ড দিন!", event.threadID, event.messageID);
  }

  const imgURL = event.messageReply.attachments[0].url;
  const filePath = path.join(__dirname, "cache", `animate_${Date.now()}.png`);
  const writer = fs.createWriteStream(filePath);

  api.sendMessage("📥 ছবি ডাউনলোড হচ্ছে...", event.threadID, event.messageID);
  const response = await axios.get(imgURL, { responseType: "stream" });
  response.data.pipe(writer);
  await new Promise((resolve) => writer.on("finish", resolve));

  api.sendMessage("🎬 অ্যানিমেশন তৈরি হচ্ছে, অনুগ্রহ করে একটু অপেক্ষা করুন...", event.threadID, event.messageID);

  try {
    const result = await imgToVideo(prompt, filePath, duration);
    const videoURL = result[0].video_url;

    api.sendMessage(
      {
        body: `✅ সম্পন্ন!\n📝 Prompt: ${prompt}\n🕒 Duration: ${duration}s`,
        attachment: await getStreamFromURL(videoURL),
      },
      event.threadID,
      event.messageID
    );

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error("Animate error:", err);
    api.sendMessage("❌ অ্যানিমেশন তৈরিতে সমস্যা হয়েছে!", event.threadID, event.messageID);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
};