module.exports = function ({ api, models, Users, Threads, Currencies }) {
    const logger = require("../../utils/log.js");
    const moment = require("moment-timezone");

    return function ({ event }) {
        try {

            const timeStart = Date.now();
            const time = moment.tz("Asia/Dhaka").format("HH:mm:ss L");

            const { userBanned, threadBanned } = global.data;
            const { events } = global.client;
            const { allowInbox, DeveloperMode } = global.config;

            var { senderID, threadID } = event;
            senderID = String(senderID);
            threadID = String(threadID);

            if (
                userBanned.has(senderID) ||
                threadBanned.has(threadID) ||
                (allowInbox == false && senderID == threadID)
            ) return;

            for (const [key, value] of events.entries()) {

                // ✅ SAFE CHECK (CRASH PROTECTION)
                if (
                    !value ||
                    !value.config ||
                    !Array.isArray(value.config.eventType) ||
                    !event ||
                    !event.logMessageType
                ) continue;

                if (value.config.eventType.includes(event.logMessageType)) {

                    const eventRun = events.get(key);

                    try {
                        const Obj = {};
                        Obj.api = api;
                        Obj.event = event;
                        Obj.models = models;
                        Obj.Users = Users;
                        Obj.Threads = Threads;
                        Obj.Currencies = Currencies;

                        eventRun.run(Obj);

                        if (DeveloperMode === true)
                            logger(
                                global.getText(
                                    'handleEvent',
                                    'executeEvent',
                                    time,
                                    eventRun.config.name,
                                    threadID,
                                    Date.now() - timeStart
                                ),
                                '[ Event ]'
                            );

                    } catch (error) {
                        logger(
                            global.getText(
                                'handleEvent',
                                'eventError',
                                eventRun?.config?.name || "Unknown",
                                JSON.stringify(error)
                            ),
                            "error"
                        );
                    }
                }
            }

        } catch (err) {
            console.log("HandleEvent Fatal Error:", err.message);
        }

        return;
    };
};