const axios = require('axios');

module.exports = {
    config: {
        name: 'freeinfo',
        version: '1.3',
        hasPermission: 0,
        credits: 'RAHAT😍🌹',
        countDown: 10,
        usePrefix: true,
        prefix: true,
        commandCategory: 'info',
        groupAdminOnly: false,
        description: 'Fetches detailed Free Fire user info from the provided API.',
        category: 'info',
        guide: {
            en: '{pn}ffin <uid>'
        },
    },
    run: async ({ api, event, args }) => {
        const uid = args[0]?.replace(/[^0-9]/g, '');
        if (!uid) return api.sendMessage('Please provide a valid UID.', event.threadID);

        const apiUrl = `https://hridoy-ff-1.onrender.com/api/info?uid=${uid}`;

        try {
            const response = await axios.get(apiUrl, { timeout: 5000 });
            const data = response.data;

            if (data.error || !data.basicInfo) {
                return api.sendMessage(
                    data.error 
                        ? `API Error: ${data.error}. Contact: ${data.contact || 't.me/BD_NOOBRA'}`
                        : 'Invalid or missing user data. Please check the UID.',
                    event.threadID
                );
            }

            const {
                _resolved_region = 'N/A',
                basicInfo: {
                    accountId = 'N/A', nickname = 'N/A', level = 0, exp = 0, liked = 0, rank = 0,
                    csRank = 0, csMaxRank = 0, csRankingPoints = 0, maxRank = 0, rankingPoints = 0,
                    region = 'N/A', createAt = '0', lastLoginAt = '0', badgeCnt = 0, badgeId = 0,
                    bannerId = 0, headPic = 0, pinId = 0, title = 0, releaseVersion = 'N/A',
                    seasonId = 0, showBrRank = false, showCsRank = false, showRank = false,
                    weaponSkinShows = [], externalIconInfo: { showType = 'N/A', status = 'N/A' } = {}
                } = {},
                captainBasicInfo: {
                    accountId: captainId = 'N/A', nickname: captainNickname = 'N/A', level: captainLevel = 0,
                    exp: captainExp = 0, liked: captainLiked = 0, rank: captainRank = 0, csRank: captainCsRank = 0,
                    csMaxRank: captainCsMaxRank = 0, csRankingPoints: captainCsRankingPoints = 0,
                    maxRank: captainMaxRank = 0, rankingPoints: captainRankingPoints = 0, region: captainRegion = 'N/A',
                    createAt: captainCreateAt = '0', lastLoginAt: captainLastLoginAt = '0', badgeCnt: captainBadgeCnt = 0,
                    badgeId: captainBadgeId = 0, bannerId: captainBannerId = 0, headPic: captainHeadPic = 0,
                    pinId: captainPinId = 0, title: captainTitle = 0, releaseVersion: captainReleaseVersion = 'N/A',
                    seasonId: captainSeasonId = 0, showBrRank: captainShowBrRank = false,
                    showCsRank: captainShowCsRank = false, hasElitePass = false, weaponSkinShows: captainWeaponSkinShows = []
                } = {},
                clanBasicInfo: {
                    clanName = 'N/A', clanLevel = 0, memberNum = 0, capacity = 0, clanId = 'N/A', captainId: clanCaptainId = 'N/A'
                } = {},
                creditScoreInfo: {
                    creditScore = 0, periodicSummaryEndTime = '0', rewardState = 'N/A'
                } = {},
                diamondCostRes: { diamondCost = 0 } = {},
                petInfo: {
                    id: petId = 'N/A', level: petLevel = 0, exp: petExp = 0, isSelected = false,
                    selectedSkillId = 'N/A', skinId = 'N/A'
                } = {},
                profileInfo: {
                    avatarId = 'N/A', clothes = [], equipedSkills = [], isMarkedStar = false,
                    pvePrimaryWeapon = 0, unlockTime = '0'
                } = {},
                socialInfo: {
                    language = 'N/A', rankShow = 'N/A', signature = 'N/A'
                } = {}
            } = data;

            const messageBody = `
*User Info*:
👤 *Nickname*: ${nickname}
🆔 *Account ID*: ${accountId}
🌍 *Region*: ${region} (${_resolved_region})
🎮 *Level*: ${level}
🔥 *EXP*: ${exp}
❤️ *Likes*: ${liked}
🏅 *Rank*: ${rank} (Max: ${maxRank}, Points: ${rankingPoints})
🔫 *CS Rank*: ${csRank} (Max: ${csMaxRank}, Points: ${csRankingPoints})
📅 *Created*: ${createAt !== '0' ? new Date(parseInt(createAt) * 1000).toLocaleDateString() : 'N/A'}
📲 *Last Login*: ${lastLoginAt !== '0' ? new Date(parseInt(lastLoginAt) * 1000).toLocaleDateString() : 'N/A'}
🎖️ *Badges*: ${badgeCnt}
🖼️ *Badge ID*: ${badgeId}
🏷️ *Banner ID*: ${bannerId}
👨‍🎤 *Head Pic ID*: ${headPic}
📌 *Pin ID*: ${pinId}
🏆 *Title ID*: ${title}
📦 *Release Version*: ${releaseVersion}
📆 *Season ID*: ${seasonId}
🏅 *Show BR Rank*: ${showBrRank ? 'Yes' : 'No'}
🔫 *Show CS Rank*: ${showCsRank ? 'Yes' : 'No'}
🏆 *Show Rank*: ${showRank ? 'Yes' : 'No'}
🔫 *Weapon Skins*: ${weaponSkinShows.length ? weaponSkinShows.join(', ') : 'None'}
🌐 *External Icon*: ${showType} (${status})

*Clan Info*:
🏰 *Clan Name*: ${clanName}
🆙 *Clan Level*: ${clanLevel}
👥 *Members*: ${memberNum}/${capacity}
🆔 *Clan ID*: ${clanId}
👑 *Captain ID*: ${clanCaptainId}

*Captain Info*:
👤 *Nickname*: ${captainNickname}
🆔 *Account ID*: ${captainId}
🌍 *Region*: ${captainRegion}
🎮 *Level*: ${captainLevel}
🔥 *EXP*: ${captainExp}
❤️ *Likes*: ${captainLiked}
🏅 *Rank*: ${captainRank} (Max: ${captainMaxRank}, Points: ${captainRankingPoints})
🔫 *CS Rank*: ${captainCsRank} (Max: ${captainCsMaxRank}, Points: ${captainCsRankingPoints})
📅 *Created*: ${captainCreateAt !== '0' ? new Date(parseInt(captainCreateAt) * 1000).toLocaleDateString() : 'N/A'}
📲 *Last Login*: ${captainLastLoginAt !== '0' ? new Date(parseInt(captainLastLoginAt) * 1000).toLocaleDateString() : 'N/A'}
🎖️ *Badges*: ${captainBadgeCnt}
🖼️ *Badge ID*: ${captainBadgeId}
🏷️ *Banner ID*: ${captainBannerId}
👨‍🎤 *Head Pic ID*: ${captainHeadPic}
📌 *Pin ID*: ${captainPinId}
🏆 *Title ID*: ${captainTitle}
📦 *Release Version*: ${captainReleaseVersion}
📆 *Season ID*: ${captainSeasonId}
🏅 *Show BR Rank*: ${captainShowBrRank ? 'Yes' : 'No'}
🔫 *Show CS Rank*: ${captainShowCsRank ? 'Yes' : 'No'}
🎫 *Elite Pass*: ${hasElitePass ? 'Yes' : 'No'}
🔫 *Weapon Skins*: ${captainWeaponSkinShows.length ? captainWeaponSkinShows.join(', ') : 'None'}

*Credit Score Info*:
⭐ *Credit Score*: ${creditScore}
⏰ *Summary End*: ${periodicSummaryEndTime !== '0' ? new Date(parseInt(periodicSummaryEndTime) * 1000).toLocaleDateString() : 'N/A'}
🎁 *Reward State*: ${rewardState}

*Diamond Cost*:
💎 *Cost*: ${diamondCost}

*Pet Info*:
🐾 *Pet ID*: ${petId}
🆙 *Level*: ${petLevel}
🔥 *EXP*: ${petExp}
✅ *Selected*: ${isSelected ? 'Yes' : 'No'}
🛠️ *Skill ID*: ${selectedSkillId}
🎨 *Skin ID*: ${skinId}

*Profile Info*:
🖼️ *Avatar ID*: ${avatarId}
👕 *Clothes*: ${clothes.length ? clothes.join(', ') : 'None'}
🛠️ *Equipped Skills*: ${equipedSkills.length ? equipedSkills.join(', ') : 'None'}
⭐ *Marked Star*: ${isMarkedStar ? 'Yes' : 'No'}
🔫 *PvE Weapon*: ${pvePrimaryWeapon}
🔓 *Unlock Time*: ${unlockTime !== '0' ? new Date(parseInt(unlockTime) * 1000).toLocaleDateString() : 'N/A'}

*Social Info*:
🌐 *Language*: ${language}
🏅 *Rank Show*: ${rankShow}
💬 *Signature*: ${signature}
            `;

            api.sendMessage(messageBody.trim(), event.threadID);
        } catch (error) {
            console.error('Error fetching user info:', error);
            let errorMsg = 'Failed to fetch user info. Try again later.';
            if (error.response?.status === 500) {
                errorMsg = 'API server error (500). Contact t.me/BD_NOOBRA for support.';
            } else if (error.code === 'ECONNABORTED') {
                errorMsg = 'Request timed out. Please try again.';
            } else if (error.name === 'TypeError') {
                errorMsg = 'Invalid data format received from API. Please check the UID or try again.';
            }
            api.sendMessage(errorMsg, event.threadID);
        }
    },
};